<?php

namespace GloBee\PaymentApi\Exceptions\Http;

class NotFoundException extends HttpException
{
}
