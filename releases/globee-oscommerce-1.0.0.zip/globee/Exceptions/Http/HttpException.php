<?php

namespace GloBee\PaymentApi\Exceptions\Http;

class HttpException extends \RuntimeException
{
}
