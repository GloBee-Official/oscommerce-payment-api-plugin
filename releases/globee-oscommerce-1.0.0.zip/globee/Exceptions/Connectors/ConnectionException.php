<?php

namespace GloBee\PaymentApi\Exceptions\Connectors;

class ConnectionException extends \RuntimeException
{
}
