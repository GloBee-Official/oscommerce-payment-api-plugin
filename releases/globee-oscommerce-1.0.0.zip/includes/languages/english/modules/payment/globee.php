<?php

/**
 * Language Text
 */

define('MODULE_PAYMENT_GLOBEE_TEXT_TITLE', 'GloBee Cryptocurrency Payments');
define('MODULE_PAYMENT_GLOBEE_TEXT_DESCRIPTION', 'Accept payments in multiple crypto currencies, supported by GloBee.');
define('MODULE_PAYMENT_GLOBEE_BAD_CURRENCY', 'The chosen currency is not supported by GloBee.');
define('MODULE_PAYMENT_GLOBEE_ERROR_DEFAULT', 'Unable to process payment using GloBee.');
define('MODULE_PAYMENT_GLOBEE_ERROR_TIMEOUT', 'The checkout process timed out. Please try again.');
define('MODULE_PAYMENT_GLOBEE_ERROR_CONNECTION', 'The checkout failed to connect. Please try again.');