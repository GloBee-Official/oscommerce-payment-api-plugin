<?php

namespace GloBee\PaymentApi\Exceptions\Http;

class ForbiddenException extends HttpException
{
}
